#pragma once

namespace Math {

	float interpolate(const float &startValue, const float &endValue, const float &stepNumber, const float &lastStepNumber);

}